<?php
$presets = array();

$presets[] = array( "name"			=> __("About Me", "mthemelocal" ),
					"slug"			=> "about-me");

$presets[] = array( "name"			=> __("About Me II", "mthemelocal" ),
					"slug"			=> "about-me-ii");

$presets[] = array( "name"			=> __("About Us", "mthemelocal" ),
					"slug"			=> "about-us");

$presets[] = array( "name"			=> __("Contact Us", "mthemelocal" ),
					"slug"			=> "contact-us");

$presets[] = array( "name"			=> __("Our Services", "mthemelocal" ),
					"slug"			=> "services");

$presets[] = array( "name"			=> __("Our Services II", "mthemelocal" ),
					"slug"			=> "services-ii");
?>